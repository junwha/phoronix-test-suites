# Windows Previewers for Basis Universal

Build using Visual Studio from 2012 onwards. Enable from an Administrator console using `regsvr32 previewers.dll` (and remove using `regsvr32 /u previewers.dll`).

![Icon and preview pane](preview.png)

Work-in-progress. Prebuilt signed version and installer coming soon. Mac version to follow.

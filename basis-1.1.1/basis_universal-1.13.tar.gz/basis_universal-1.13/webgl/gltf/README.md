## Credits

* Contributors:
  * [Don McCurdy](https://www.donmccurdy.com)
  * [Austin Eng](https://github.com/austinEng)
  * [Shrek Shao](https://github.com/shrekshao)
* Made with [three.js](https://threejs.org/).
* Thanks to [AGI](http://agi.com/) for providing the glTF model.

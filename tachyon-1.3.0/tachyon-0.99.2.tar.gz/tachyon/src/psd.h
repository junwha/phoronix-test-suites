/*
 *  psd.h - This file deals with Photoshop format image files (reading/writing)
 *
 *  $Id: psd.h,v 1.2 2007/02/13 04:38:48 johns Exp $
 */ 

int writepsd48(char *name, int xres, int yres, unsigned char *imgdata);



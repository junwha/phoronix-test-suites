#ifndef SIMDUTILS_HPP_
#define SIMDUTILS_HPP_

#include "SimdBool.hpp"
#include "SimdFloat.hpp"
#include "SimdVec.hpp"

#endif /* SIMDUTILS_HPP_ */

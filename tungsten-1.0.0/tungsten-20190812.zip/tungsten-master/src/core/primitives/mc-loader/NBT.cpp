#include "NBT.hpp"

namespace Tungsten {
namespace MinecraftLoader {

NbtTag NbtTag::InvalidTag;

}
}

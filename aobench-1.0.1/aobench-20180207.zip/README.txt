aobench is originally written by Syoyo Fujita.

 License: New BSD License 

code.google.com/p/aobench 


Modifications for Phoronix Test Suite:

- SET WIDTH x HEIGHT TO 2048
